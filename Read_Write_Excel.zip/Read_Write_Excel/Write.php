<?php
error_reporting(E_ALL);
ini_set('display_errors', '1');
date_default_timezone_set('Asia/Kolkata');
        require_once 'phpexcel2/Classes/PHPExcel/IOFactory.php';
        $objPHPExcel = PHPExcel_IOFactory::load("myExcelFile.xlsx");

$objPHPExcel->setActiveSheetIndex(0);
$row = $objPHPExcel->getActiveSheet()->getHighestRow()+1;
//echo $row;
$objPHPExcel->getActiveSheet()->SetCellValue('A'.$row, date("Y-m-d",time()));
$objPHPExcel->getActiveSheet()->SetCellValue('B'.$row, date("h:i:sa"));
$objPHPExcel->getActiveSheet()->SetCellValue('C'.$row, "C");
$objWriter = new PHPExcel_Writer_Excel2007($objPHPExcel);
$objWriter->save('myExcelFile.xlsx');
       
   
        ?>